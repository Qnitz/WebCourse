window.onload = () => {

    // $("#form_submit_btn").click(function () {
    //     $("body").css("background-color", "#a5c3fd");
    // });

    $("#form_submit_btn").click(function () {
        console.log("submit pressed.\n");
    });

    $("#top_btn_row").click(function () {
        console.log("top roq button pressed.\n");
    });

    
}